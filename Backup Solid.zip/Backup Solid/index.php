<!DOCTYPE html> 	<head> 	<style>
.box {
border: 10px solid green;
width:50%;
font-size:4em;
border-radius: 50px 10px 50px 10px;
margin:10%;
padding:14px;
}
</style>	<meta charset="utf-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=device-width, initial-scale=1"> <title>Solid Member Dashboard</title>	<meta charset="utf-8" /> 	
<meta name="viewport" content="width=device-width, initial-scale=1" /> 		 <!--[if lte IE 8]> <script src="assets/js/ie/html5shiv.js"></script><![endif]--> 		<link rel="stylesheet" href="assets/css/main.css" /> 	 	<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]--> 		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]--> 	<!-- Page Wrapper --> 			<div id="page-wrapper"> 				<!-- Header --> 					<header id="header" class="alt"> 						<h1><a href="home.php">Solid Matrix</a></h1> 
				<nav> 							<a href="#menu">Navigation</a> 						</nav> 					</header> 				<!-- Menu --> 					<nav id="menu"> 						<div class="inner"> 							<h2>Navigation</h2> 							<ul class="links"> 								<li><a href="home.php">Home</a></li> 							<li><a href="index.php">Dashboard</a></li> <li><a href="upgrade.php">Upgrade Account</a>
</li><li><a href="howitworks.php">How it works</a></li> 				<li><a href="Ann.php">Announcments</a>
</li>				<li><a href="faqs.php">FAQs</a></li> 																<li><a href="logout.php">Logout</a></li> 			 <li><a href="aboutus.php">About us</a></li>				<li><a href="terms.php">Terms & Conditions</a>
</li></ul> 							<a href="#" class="close">Close</a> 						</div> 					</nav> 		 		<!-- Banner --> 		 			<section id="banner"> 						<div class="inner"> 						 			
</head>
<body>
<?php include "dash.php"; ?>
<h1><?php include "indx.php"; ?></h1>
<div class="front-page"> <h1>Member Dashboard</h1>


<div class="col-md-6 fs20 alert alert-info"> Your Free membership expires soon! <br/> <b><a href="upgrade.php">Upgrade</a></b> before time runs out or your account will be deleted. </div> <div class="col-md-6 m-t-20">
<div class="countdown-display" data-secs="172546">
<p class="box">
<span id="countdown" class="timer"></span> <script> var upgradeTime = 86400; var seconds = upgradeTime; function timer() { var days = Math.floor(seconds/24/60/60); var hoursLeft = Math.floor((seconds) - (days*86400)); var hours = Math.floor(hoursLeft/3600); var minutesLeft = Math.floor((hoursLeft) - (hours*3600)); var minutes = Math.floor(minutesLeft/60); var remainingSeconds = seconds % 60; if (remainingSeconds < 10) { remainingSeconds = "0" + remainingSeconds; } document.getElementById('countdown').innerHTML = days + ":" + hours + ":" + minutes + ":" + remainingSeconds; if (seconds == 0) { clearInterval(countdownTimer); document.getElementById('countdown').innerHTML = "Account is bieng deleted"; } else { seconds--; } } var countdownTimer = setInterval('timer()', 1000); </script></p>
 </div> <div class="m-t-10 center"> You can't receive referrals or donations until you upgrade. </div> </div> <div class="clear"></div> </div><div class="row">
<div class="memberSummary col-md-6"> <table class="table"> <tr> <td class="center"><img src="images/pic01.png" width="450"/> <br/> Stage: <b></b> </td>
<div class="col-lg-12"> <div class="tile"> <h2 class="tile-title">Referral Summary</h2>

<div id="memberSummary"> <table class="rwd-table"> <tr> <th>Level</th> <th>Donation</th> <th class="right">Max. Referrals</th> <th class="right">Referrals</th> <th class="right">Received</th> <th class="right">Potential</th> </tr> <tr> <td data-th="Level"> 1 </td> <td data-th="Price"> Ƀ0.02 </td> <td data-th="Max. Referrals" class="right"> 3 (Ƀ0.06) </td> <td data-th="Referrals" class="right">0</td> <td data-th="Received" class="right"> Ƀ0.00 </td> <td data-th="Potential" class="right"> Ƀ0.00 </td> </tr>
<tr> <td data-th="Level"> 2 </td> <td data-th="Price"> Ƀ0.05 </td> <td data-th="Max. Referrals" class="right"> 3 (Ƀ0.015) </td> <td data-th="Referrals" class="right"> 0</td> <td data-th="Received" class="right"> Ƀ0.00 </td> <td data-th="Potential" class="right"> Ƀ0.00 </td> </tr>
<tr> <td data-th="Level"> 3 </td> <td data-th="Price"> Ƀ0.13 </td> <td data-th="Max. Referrals" class="right"> 3 (Ƀ0.39) </td> <td data-th="Referrals" class="right">0</td> <td data-th="Received" class="right"> Ƀ0.00 </td> <td data-th="Potential" class="right"> Ƀ0.00 </td> </tr>
 </tr>
<tr> <td data-th="Sum"class="listTotal">Total</td> <td data-th="" class="listTotal">&nbsp;</td> <td data-th="" class="listTotal right">9 (Ƀ0.42 + 2Re-entries)</td> <td data-th="Referrals" class="listTotal right">0</td> <td data-th="Received" class="listTotal right">Ƀ0.00</td> <td data-th="Potential" class="listTotal right">Ƀ0.00</td> </tr></table> </div>
</div></div> </div> </div> </div> </div>
</section></div> </div> </div> </div> </div> </div></div>
 				<!-- Footer --> 					<section id="footer"> 						<div class="inner"> 									<ul class="contact"> 																<li class="fa-phone">(067) 546-8296</li> 								<li class="fa-envelope"><a href="mailto:Hassanraza.king1@gmail.com">Contact us</a></li> 								<li class="fa-facebook"><a href="fb.com/hassanrazaking.king">Facebook</a></li> 								<li class="fa-instagram"><a href="instagram.com/#">Instagram</a></li> 							</ul> 							<ul class="copyright"> 								<li>&copy; Solid Inc. All rights reserved.</li><li>Scripts by: <a href="mailto:hassanraza.king1@gmail.com"></a>King</li> 							</ul> 						</div> 					</section> 			</div>					</section> 			</div> 		<!-- Scripts --> 			<script src="assets/js/skel.min.js"></script> 			<script src="assets/js/jquery.min.js"></script> 			<script src="assets/js/jquery.scrollex.min.js"></script> 			<script src="assets/js/util.js"></script> 			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]--> 			<script src="assets/js/main.js"></script> 	</body> 

</body>
</html>
