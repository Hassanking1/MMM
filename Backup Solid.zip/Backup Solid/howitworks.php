<!DOCTYPE HTML>
<html>
	<head><?php 
include "logo.php";
?>
		<meta charset="utf-8">
    <meta name="keywords" content="contributions, member to member, peer to peer, funding, crowd, crowd funding">
    <meta name="description" content="Member to Member Contributions Platform">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>How It Works | Solid</title>
                   
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header">
						<h1><a href="home.php">Solid Matrix</a></h1>
						<nav>
							<a href="#menu">Menu</a>
						</nav>
					</header>

				<!-- Menu -->
					<nav> 							<a href="#menu">Menu</a> 						</nav> 					</header> 				<!-- Menu --> 					<nav id="menu"> 						<div class="inner"> 							<h2>Menu</h2> 							<ul class="links"> 								<li><a href="home.php">Home</a></li> 								<li><a href="howitworks.php">How it works</a></li> 								<li><a href="faqs.php">FAQs</a></li> 								<li><a href="login.php">Log In</a></li> 								<li><a href="register.php">Sign Up</a></li> 			 <li><a href="aboutus.php">About us</a></li>				<li><a href="terms.php">Terms & Conditions</a>
</li></ul> 							<a href="#" class="close">Close</a> 						</div> 					</nav>

				<!-- Wrapper -->
					<section id="wrapper">
						<header>
							<div class="inner">
								<h2>How it Works</h2>
								<p>Please take a moment to read this.</p>
							</div>
						</header>

						<!-- Content -->
							<div class="wrapper">
								<div class="inner">

									<section>
										
                    <p style="text-align: center;"><strong><span style="font-family: helvetica; font-size: 36pt;">HOW IT WORKS</span></strong></p>
<p dir="ltr" style="text-align: center;"><br /><span style="font-family: helvetica; font-size: 24pt; color: #ff0000; background-color: #ffff00;"><strong>*** SOLID STRATEGY ***</strong></span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">Strategy Upgrade Profit</span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">THIS IS  OPTIONAL ON EVERYONE JUST GETTING 1-3 participants (if you can have more than 3 you can help you downline by placing these people under them)</span></p><img style="display: block; margin-left: auto; margin-right: auto;" src="images/pic01.png" alt="" width="300" height="150" />
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">LEVEL 1:  3 x 0.02btc </span><br /><span style="font-family: helvetica; font-size: 14pt;">= 0.06btc – 0.05btc (upgrade to level 2)</span><br /><span style="font-family: helvetica; font-size: 14pt;">= 0.01btc profit</span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">LEVEL 2:  3 x 0.05btc</span><br /><span style="font-family: helvetica; font-size: 14pt;">= 0.15btc – 0.13btc (upgrade to level 3)</span><br /><span style="font-family: helvetica; font-size: 14pt;">= 0.02btc profit</span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">LEVEL 3:  3 x 0.13btc </span><br /><span style="font-family: helvetica; font-size: 14pt;">= 0.39btc – N/A btc (no upgrade) </span><br /><span style="font-family: helvetica; font-size: 14pt;">= 0.39btc profit</span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">LET'S WORK TOGETHER AS A TEAM</span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">NB!! NB!! NB!! </span><br /><span style="font-family: helvetica; font-size: 14pt;">AS SOON AS YOU RECEIVED ENOUGH ON EVERY LEVEL,IT'LL AUTOMATICALLY UPGRADE YOU TO THE NEXT LEVEL!!!</span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">ON LEVEL 1 AFTER YOUR FIRST 3 DONATIONS</span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">ON LEVEL 2 AFTER YOUR FIRST 3 DONATIONS</span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">ON LEVEL 3 AFTER YOUR FIRST 3 DONATIONS</span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">ON LEVEL 3 ENJOY YOUR MASSIVE PROFITS!!! ON NEXT 2 ENTRIES, YOU WILL BE RECEIVING IT ALL OVER AGAIN!</span></p>
<p dir="ltr" style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;">REMEMBER TO KEEP SHARING OUR MONEY MAKING PLATFORM.</span></p>
</section>
				<!-- Footer -->
					<section id="footer">
						<div class="inner">
							
							<ul class="contact"> 						<div class="inner"> 																								<li class="fa-phone">(067) 546-8296</li> 								<li class="fa-envelope"><a href="mailto:Hassanraza.king1@gmail.com">Contact us</a></li> 								<li class="fa-facebook"><a href="fb.com/hassanrazaking.king">Facebook</a></li> 								<li class="fa-instagram"><a href="instagram.com/#">Instagram</a></li> 							</ul> 							<ul class="copyright"> 								<li>&copy; Solid Inc. All rights reserved.</li><li>Scripts by: <a href="mailto:hassanraza.king1@gmail.com"></a>King</li> 							</ul> 						</div> 					</section> 			</div> 			<!-- Scripts -->
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>