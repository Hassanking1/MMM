<!DOCTYPE HTML>
<html>
	<head><?php 
include "logo.php";
?>
    <meta charset="utf-8">
    <meta name="keywords" content="contributions, member to member, peer to peer, funding, crowd, crowd funding">
    <meta name="description" content="Member to Member Contributions Platform">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> T & C | Solid</title>
    <script src="/cdn-cgi/apps/head/VAJ5gVQeZIkHrO9JprS30wkz4Sk.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header">
						<h1><a href="home.php">Solid Matrix</a></h1>
						<nav> 							<a href="#menu">Menu</a> 						</nav> 					</header> 				<!-- Menu --> 				<nav id="menu"> 						<div class="inner"> 							<h2>Menu</h2> 							<ul class="links"> 								<li><a href="home.php">Home</a></li> 								<li><a href="howitworks.php">How it works</a></li> 								<li><a href="faqs.php">FAQs</a></li> 								<li><a href="login.php">Log In</a></li> 								<li><a href="register.php">Sign Up</a></li> 			 <li><a href="aboutus.php">About us</a></li>			<li><a href="terms.php">Terms & Conditions

</a>

</li>	</ul> 							<a href="#" class="close">Close</a> 						</div> 					</nav>

				<!-- Wrapper -->
					<section id="wrapper">
						<header>
							<div class="inner">
								<h2>T&C</h2>
								<p>Terms and Conditions.</p>
							</div>
						</header>

						<!-- Content -->
							<div class="wrapper">
								<div class="inner">

									<h3 class="major">Please take a moment to read them.</h3>
							<section class="second-sectio-back min">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="front-page">
                    <p><span style="text-decoration: underline;"><span style="font-family: helvetica; font-size: 18pt;"><strong>Terms & Conditions</strong></span></span></p>


<p><span style="font-size: 12pt;">By signing up with SOLID, you agree to the following Terms, Conditions and Disclaimers:</span></p>
<p><span style="font-size: 12pt;">This service is provided on an as is, as available service. We make no warranties of any kind, either expressed or implied.</span></p>
<ol>
<li><span style="font-size: 12pt;">You understand that there is specific guidelines and policies in place. </span></li>
</ol>
<ol start="2">
<li><span style="font-size: 12pt;">You also understand that you have to avail yourself of how Solid works before you join SOLID, failing to Step-up (Upgrade, make a 0.02BTC donation to the system) will cause the system to delete your account, you are welcome to join again and get a second 24-hour period to decide to participate, failing to participate will get you banned from joining the SOLID community again. </span></li>
</ol>
<ol start="3">
<li><span style="font-size: 12pt;">You have read and understood that "Spamming" and or cross recruiting meaning contacting other participants in an attempt to promote ANY other opportunity to ANY fellow SOLID participant is grounds for "Immediate" account suspension which disqualifies you from receiving spill over, new sign-ups as well as donations.</span></li>
</ol>
<ul>
<li>
<p><span style="font-size: 12pt;">Under no circumstances, including negligence, shall anyone involved in creating, producing or distributing this service, be liable for any direct, indirect, incidental, special or consequential damages that result from the use of, or inability to use this service, and all the files and software contained within it, including, but not limited to, reliance on any information obtained through this service; or that result from mistakes, omissions, interruptions, deletion of files or e-mail, errors, defects, viruses, delays in operation, or transmission, or any failure of performance, whether or not limited to acts beyond our control, communications failure, theft, destruction or unauthorized access to our records, programs or services.</span></p>
</li>
</ul>
<ul>
<li>
<p><span style="font-size: 12pt;">We reserve the right to add or remove features and modify any functionality, make changes on how the platform works, manage memberS, within SOLID, and otherwise make changes to the service and this agreement without notice.</span></p>
</li>
</ul>
<ul>
<li>
<p><span style="font-size: 12pt;">Sites and individuals involved with the following activities are NOT ELIGIBLE: selling, providing or linking to unlicensed content, pornography, warez, pirated software, hacking or spamming software, email address lists or harvesting software, or any materials endorsing violence, hatred, revenge, racism, victimization, or criminal activity. </span></p>
</li>
</ul>
<ul>
<li>
<p><span style="font-size: 12pt;">We make no claims on how much money you can make with our program. Your ability to earn depends on a number of factors, including where and how (and how often) you advertise the program, and the motivation and ability of those in your up lines, to make referrals. Individual results will vary. </span></p>
</li>
</ul>
<ul>
<li>
<p><span style="font-size: 12pt;">Members caught spamming or otherwise causing harm to our program will have their accounts terminated, and maybe prosecuted for their actions. We will investigate all allegations before taking action. </span></p>
</li>
</ul>
<ul>
<li>
<p><span style="font-size: 12pt;">All donations you willingly and directly send to the system are final. No refunds. </span></p>
</li>
</ul>
<ul>
<li>
<p><span style="font-size: 12pt;">You understand that all donations will be made directly by donators to you to your payment processor, and that any problems you have concerning such matters should be taken up with your respective merchant account provider. </span></p>
</li>
</ul>
<ul>
<li>
<p><span style="font-size: 12pt;">You agree to accept email updates regarding Solid. We will never inundate you with emails or spam. Report spam and other abuse via the contact form. </span></p>
</li>
</ul>
<ul>
<li>
<p><span style="font-size: 12pt;">Please include the entire spam email with headers. </span></p>
</li>
</ul>
<ul>
<li>
<p><span style="font-size: 12pt;">If any member is caught stacking, SOLID reserves the right to move the stacked accounts further down the matrix and/or block the stacked accounts. </span></p>
</li>
</ul>
<p><span style="font-size: 12pt;">Enjoy giving and receiving donations with SOLID. <br /></span></p>
<p><span style="font-size: 12pt;"><strong>The SOLID Team</strong></span></p>
<p>​</p> 

				<!-- Footer -->
				<section id="footer"> 						<div class="inner"> 									<ul class="contact"> 																<li class="fa-phone">(067) 546-8296</li> 								<li class="fa-envelope"><a href="mailto:Hassanraza.king1@gmail.com">Contact us</a></li> 								<li class="fa-facebook"><a href="fb.com/hassanrazaking.king">Facebook</a></li> 								<li class="fa-instagram"><a href="instagram.com/#">Instagram</a></li> 							</ul> 							<ul class="copyright"> 								<li>&copy; Solid Inc. All rights reserved.</li><li>Scripts by: <a href="mailto:hassanraza.king1@gmail.com"></a>King</li> 							</ul> 						</div> 					</section> 			</div>		<!-- Scripts -->
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>