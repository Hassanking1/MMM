
<p class="box">
<?php
include "home.php";
 $input = array("1FfdhQWaMoKzakN3Bd2SFRpBnSHwhJX4op" ,
"1Bg6GfLjWQSwR1y8k2JyuGFCUZt3NAjxcj", "14WrD6NudAzoTQqCWWTZWXNzpG2DNH1zbt", "1Gtq4PXVjqpar639e3XEQMwqHLdifVciYb", "
1FzByranth1P75c4CwUsEc1a9fCfXK6oL1", "1JUdEwwjbzZAhPknjvQa4tXd4X17oy4hXn", "13pqrMvUTYHaQonyYFr3LSqzoXDHd5Ns8j
", "1B81hE22Hkt6xHys5MYZiy24GkbYYGHsCv", "1PeBLntN2ZvNhfSNXdi7UkVwjVqZ9J75aY", "1FG3JRgNZTWMTmb9Wni8YXFVzTAiEjyTdh
"); $rand_keys = array_rand($input, 2); echo $input[$rand_keys[0]] . "\n"; ?>

</p>
