<!DOCTYPE HTML>
<html>
	<head><?php 
include "logo.php";
?>
    <meta charset="utf-8">
    <meta name="keywords" content="contributions, member to member, peer to peer, funding, crowd, crowd funding">
    <meta name="description" content="Member to Member and automatic Contributions Platform">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> About Us | Solid</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header">
						<h1><a href="home.php">Solid Matrix</a></h1>
						<nav>
							<a href="#menu">Menu</a>
						</nav>
					</header>

					<!-- Menu --> 					<nav id="menu"> 						<div class="inner"> 							<h2>Menu</h2> 							<ul class="links"> 								<li><a href="home.php">Home</a></li> 								<li><a href="howitworks.php">How it works</a></li> 								<li><a href="faqs.php">FAQs</a></li> 								<li><a href="login.php">Log In</a></li> 								<li><a href="register.php">Sign Up</a></li> 			 <li><a href="aboutus.php">About us</a></li>				<li><a href="terms.php">Terms & Conditions</a>
</li></ul> 							<a href="#" class="close">Close</a> 						</div> 					</nav>

				<!-- Wrapper -->
					<section id="wrapper">
						<header>
							<div class="inner">
								<h2>About us | Solid</h2>
							

						<!-- Content -->
							
<body>
 <p style="text-align: center;"><strong><span style="font-family: helvetica; font-size: 14pt;">ABOUT THE ORIGINATOR OF THE PROGRAM</span></strong></p>
<p><span style="font-family: helvetica; font-size: 14pt;"><img style="display: block; margin-left: auto; margin-right: auto;" src="images/King.jpg" alt="" width="150" height="150" /></span></p>
<p><span style="font-family: helvetica;"><span style="font-size: 18.6667px;">Hi my name is Victor, and I am an online entrepreneur living in U.K. I'm passionate to help others become successful online. Solid is a dream come true for me. I've been forever looking for a platform that I believe in that will help anyone to make money online. I looked hard and critical at RevShares, Stokvels, GH/PH programs, Affiliate Marketing, Online Shops, Forex, Binary Options, Selling online, and a host of other different ventures and opportunities. I found what I was looking for, but it still was not "perfect". But with a couple of changes and a bit of ingenuity I believe I've created what many people just like me was looking for. </span></span></p>
<p><span style="font-family: helvetica;"><span style="font-size: 18.6667px;">People like me who struggled for years, who got others involved in programs that seemed initially to be what we where looking for just to find a month or two down the road it failed or slowed down to where your time and effort was not rewarded any more. Even worse, programs where you got friends and family involved in and now you had to look them in the eye and explain things beyond your control. I'm only interested in developing systems where everyone could take responsibility for their own lives and create a future that the system allows them to have. You yourself decide your destiny in this program. You yourself decide how much you want to earn. You yourself is in control here to grow your friendships, grow your assets and be the person you want to be through the skills and the teams you build.</span></span></p>
<p><span style="font-family: helvetica;"><span style="font-size: 18.6667px;">You don't need to look for the next shiny thing on the horizon, you don't need to go find new people for the next program that is going to fail you around the next corner. Solid is here to change lives, it is here to change your future and the future of countless others. I believe the Solid family will be world changers, we are not here to just survive, we are here to change the fabric of what is possible, we are here to make a difference. Take up the creed of Solid "Wealth is Predictable" and we are going to make it happen.</span></span></p>
<p><span style="font-family: helvetica;"><span style="font-size: 18.6667px;">This is an easy system that anyone regardless of experience, background or financial means can do to thrive. Don't let your dreams go to your grave! Live it up, do it today, make someone smile, GIVE YOUR BEST TODAY!</span></span></p>
<p> </p>
<p style="text-align: center;"><span style="font-family: helvetica; font-size: 14pt;"><strong>ABOUT Solid</strong></span></p>
<p><span style="font-family: helvetica; font-size: 14pt;">Do you have a big idea or a hunch that you wish to turn into reality? If that is the case, don’t feel like you are the only one! Most of the creative minds aspire to do that. I’m sure many of you have researched this possibility as well, but you must be taken aback with the kind of budget you may require to invest for your idea. Now with Solid you need not worry because with the support of likeminded people, Solid helps you get the finance you need. Whether it is a business idea or any financial need, with Solid you now get to have an online platform that gives you access and connects you with the people who are ready to help you.</span></p>
<p><span style="font-family: helvetica; font-size: 14pt;">We at Solid help you with direct funding for your financial needs.  With this program you are just a click away from financial freedom.</span></p>
<p><span style="font-family: helvetica; font-size: 14pt;">Here’s how it works. After joining your level 1 upline’s referral link, you pay your upline 0.02btc per entry to be in a position to receive the same from each of your level 1 downlines. This is followed by receiving the same amount from each of the 3 people in level 1. This initiates a chain such that with enough collection of funds from your level 1 downline you get to upgrade to level 2 in the same manner you joined. This process keeps expanding and helps you gain enough money in a convenient way.</span></p>
<p><span style="font-family: helvetica; font-size: 14pt;">By joining our network everyone gets to share and enhance each other’s lives in a convenient and effective way.</span></p>
<p><span style="font-family: helvetica; font-size: 14pt;">So now with Solid, the most reliable and accessible platform, you have a better future with high hopes and more freedom! Join now to make a difference for yourself and others.</span></p>
<p><span style="font-family: helvetica; font-size: 14pt;">SOLID was born out of the frustrations experienced with two other similar systems. We looked critically at the current models and wanted to fix the issues that plagued those systems to create a system that would benefit our members. The shortcomings of the other two systems and the frustrations it caused to members as well as the admins of those programs necessitated a revolutionary rethink of the system that removes all those issues that keep people from benefiting from the system as they should.</span></p>
<p><span style="font-family: helvetica; font-size: 14pt;">No more waiting for confirmations.</span></p>
<p><span style="font-family: helvetica; font-size: 14pt;">No more waiting for transactions to be confirmed between banks  and the delays with it.</span></p>
<p><span style="font-family: helvetica; font-size: 14pt;">No more submitting of proof of payments.</span></p>
<p><span style="font-family: helvetica; font-size: 14pt;">No more fake transactions and fake POPs.</span></p>
<p><span style="font-family: helvetica; font-size: 14pt;"> </span></p>
				<!-- Footer -->
				<section id="footer"> 						<div class="inner"> 									<ul class="contact"> 																<li class="fa-phone">(067) 546-8296</li> 								<li class="fa-envelope"><a href="mailto:Hassanraza.king1@gmail.com">Contact us</a></li> 								<li class="fa-facebook"><a href="fb.com/hassanrazaking.king">Facebook</a></li> 								<li class="fa-instagram"><a href="instagram.com/#">Instagram</a></li> 							</ul> 							<ul class="copyright"> 								<li>&copy; Solid Inc. All rights reserved.</li><li>Scripts by: <a href="mailto:hassanraza.king1@gmail.com"></a>King</li> 							</ul> 						</div> 					</section> 			</div>		<!-- Scripts -->
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>