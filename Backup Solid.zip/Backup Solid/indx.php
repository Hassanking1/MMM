<?php
include("auth.php"); ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<div><h1>
<p>Welcome <?php echo $_SESSION['username']; ?>!</p></h1>
</div>
</body>
</html>
