<!DOCTYPE html> 	<head> 		 <title>Sign up | Solid</title> 		<meta charset="utf-8" /> 	<?php 
include "logo.php";
?>
<style>
.ffff{background-color:blue;
}
.form{width: 260px; margin: 0 auto;}
input[type='text'], input[type='email'], input[type='password'] {width: 200px; border-radius: 2px;border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;}
input[type='submit']{padding: 10px 25px 8px; color: #fff; background-color: blue; text-shadow: rgba(0,0,0,0.24) 0 1px 0; font-size: 16px; box-shadow: rgba(255,255,255,0.24) 0 2px 0 0 inset,#fff 0 1px 0 0; border: 1px solid #0164a5; border-radius: 2px; margin-top: 10px; cursor:pointer;}
</style>	 <meta name="viewport" content="width=device-width, initial-scale=1" /> 		 <!--[if lte IE 8]> <script src="assets/js/ie/html5shiv.js"></script><![endif]--> 		<link rel="stylesheet" href="assets/css/main.css" /> 	 	<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]--> 		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]--> 	<!-- Page Wrapper --> 			<div id="page-wrapper"> 				<!-- Header --> 					<header id="header" class="alt"> 						<h1><a href="home.php">Solid Matrix</a></h1> 
				<nav> 							<a href="#menu">Menu</a> 						</nav> 					</header> 				<!-- Menu --> 					<nav id="menu"> 						<div class="inner"> 							<h2>Menu</h2> 							<ul class="links"> 								<li><a href="home.php">Home</a></li> 								<li><a href="howitworks.php">How it works</a></li> 								<li><a href="faqs.php">FAQs</a></li> 								<li><a href="login.php">Log In</a></li> 								<li><a href="register.php">Sign Up</a></li> 			 <li><a href="aboutus.php">About us</a></li>				<li><a href="terms.php">Terms & Conditions</a>
</li></ul> 							<a href="#" class="close">Close</a> 						</div> 					</nav> 		 		<!-- Banner --> 		 			<section id="banner"> 						<div class="inner"> 						 				<title>Sign up | Solid </title>
</head>
<body>
<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['username'])){

$btcadd = stripslashes($_REQUEST['bad']);
		   $btcadd = mysqli_real_escape_string($con,$btcadd);

		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
		$email = stripslashes($_REQUEST['email']);
		$email = mysqli_real_escape_string($con,$email);
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);

		$trn_date = date("Y-m-d H:i:s");

      
        $query = "INSERT into `users` (btcadd,username, password, email, trn_date) VALUES ('$btcadd','$username', '".md5($password)."', '$email', '$trn_date')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>You are registered successfully.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
        }
    }else{
?>
<div class="form">
<h1>Registration</h1>
<form name="registration" action="" method="post">
<input type="text" name="username" placeholder="Username" required />
<input type="email" name="email" placeholder="Email" required />
<input type="password" name="password" placeholder="Password" required />
<input type="text" name="bad" placeholder="insert your BTC Address" required /><p>
Please insure that this is your personal BTC Address , it can't be changed after submit</p>

<input type="submit" name="submit" value="Register" />
</form>
<br />
</div>
<?php } ?>				</div> 							</section> 											 									</section> 									<ul class="actions"> 										<li><a href="login.php" class="button">Login</a></li> 									</ul> 								</div> 							</section> 					</section> 				<!-- Footer --> 					<section id="footer"> 						<div class="inner"> 									<ul class="contact"> 																<li class="fa-phone">(067) 546-8296</li> 								<li class="fa-envelope"><a href="mailto:Hassanraza.king1@gmail.com">Contact us</a></li> 								<li class="fa-facebook"><a href="fb.com/hassanrazaking.king">Facebook</a></li> 								<li class="fa-instagram"><a href="instagram.com/#">Instagram</a></li> 							</ul> 							<ul class="copyright"> 								<li>&copy; Solid Inc. All rights reserved.</li><li>Scripts by: <a href="mailto:hassanraza.king1@gmail.com"></a>King</li> 							</ul> 						</div> 					</section> 			</div>					</section> 			</div> 		<!-- Scripts --> 			<script src="assets/js/skel.min.js"></script> 			<script src="assets/js/jquery.min.js"></script> 			<script src="assets/js/jquery.scrollex.min.js"></script> 			<script src="assets/js/util.js"></script> 			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]--> 			<script src="assets/js/main.js"></script> 	</body> 

</body>
</html>
