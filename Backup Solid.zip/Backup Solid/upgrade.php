<!DOCTYPE html> 	<head>

<style>
.ffff{background-color:blue;
}
.form{width: 260px; margin: 0 auto;}
input[type='text'], input[type='email'], input[type='password'] {width: 200px; border-radius: 2px;border: 1px solid #CCC; padding: 10px; color: #333; font-size: 14px; margin-top: 10px;}
input[type='submit']{padding: 10px 25px 8px; color: #fff; background-color: blue; text-shadow: rgba(0,0,0,0.24) 0 1px 0; font-size: 16px; box-shadow: rgba(255,255,255,0.24) 0 2px 0 0 inset,#fff 0 1px 0 0; border: 1px solid #0164a5; border-radius: 2px; margin-top: 10px; cursor:pointer;}
.box {
border: 10px solid green;
width:350px;
margin:0px;
padding:0px;
text-decoration:none;
}
</style>	 

 		<meta charset="utf-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=device-width, initial-scale=1"> <title>Solid Member Upgrade</title>	<meta charset="utf-8" /> 	
<meta name="viewport" content="width=device-width, initial-scale=1" /> 		 <!--[if lte IE 8]> <script src="assets/js/ie/html5shiv.js"></script><![endif]--> 		<link rel="stylesheet" href="assets/css/main.css" /> 	 	<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]--> 		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]--> 	<!-- Page Wrapper --> 			<div id="page-wrapper"> 				<!-- Header --> 					<header id="header" class="alt"> 						<h1><a href="home.php">Solid Matrix</a></h1> 
				<nav> 							<a href="#menu">Navigation</a> 						</nav> 					</header> 				<!-- Menu --> 					<nav id="menu"> 						<div class="inner"> 							<h2>Navigation</h2> 							<ul class="links"> 								<li><a href="home.php">Home</a></li> 							<li><a href="index.php">Dashboard</a></li> <li><a href="upgrade.php">Upgrade Account</a>
</li><li><a href="howitworks.php">How it works</a></li> 								<li><a href="faqs.php">FAQs</a></li> 																<li><a href="logout.php">Logout</a></li> 			 <li><a href="aboutus.php">About us</a></li>				<li><a href="terms.php">Terms & Conditions</a>
</li></ul> 							<a href="#" class="close">Close</a> 						</div> 					</nav> 		 		<!-- Banner --> 		 			<section id="banner"> 						<div class="inner"> 						 			
</head>
<body>
<?php include "dash.php"; ?>
<h1></h1>
<div class="front-page"> <h1>Member Upgrade</h1>


<?php
	require('db.php');
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['username'])){

$btcadd = stripslashes($_REQUEST['btctxid']);
		   $btcadd = mysqli_real_escape_string($con,$btcadd);

		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
		

		$trn_date = date("Y-m-d H:i:s");

      
        $query = "INSERT into `us` (btctxid,username, trn_date) VALUES ('$btcadd','$username', '$trn_date')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form'><h3>You have submitted,Your account will be upgraded after the transaction has 3 confirmations.</h3><br/>Click here to <a href='index.php'>Dashboard</a></div>";
        }
    }else{
?>
<div class="form">
<h1>Upgrade</h1>
<form name="registration" action="" method="post">
<input type="text" name="username" placeholder="Username" required /><i>Please use the same username.</i>
<input type="text" name="btctxid" placeholder="Transaction ID" required /><br> <p> Send BTC to the following address:
</p><i class="box">
<?php
 $input = array("1FfdhQWaMoKzakN3Bd2SFRpBnSHwhJX4op" ,
"1Bg6GfLjWQSwR1y8k2JyuGFCUZt3NAjxcj", "14WrD6NudAzoTQqCWWTZWXNzpG2DNH1zbt", "1Gtq4PXVjqpar639e3XEQMwqHLdifVciYb", "
1FzByranth1P75c4CwUsEc1a9fCfXK6oL1", "1JUdEwwjbzZAhPknjvQa4tXd4X17oy4hXn", "13pqrMvUTYHaQonyYFr3LSqzoXDHd5Ns8j
", "1B81hE22Hkt6xHys5MYZiy24GkbYYGHsCv", "1PeBLntN2ZvNhfSNXdi7UkVwjVqZ9J75aY", "1FG3JRgNZTWMTmb9Wni8YXFVzTAiEjyTdh
"); $rand_keys = array_rand($input, 2); echo $input[$rand_keys[0]] . "\n"; ?>
</i><br><br><input type="submit" name="submit" value="Upgrade" />
</form>
<br />
</div>
<?php } ?>		













</div>
 				<!-- Footer --> 					<section id="footer"> 						<div class="inner"> 									<ul class="contact"> 																<li class="fa-phone">(067) 546-8296</li> 								<li class="fa-envelope"><a href="mailto:Hassanraza.king1@gmail.com">Contact us</a></li> 								<li class="fa-facebook"><a href="fb.com/hassanrazaking.king">Facebook</a></li> 								<li class="fa-instagram"><a href="instagram.com/#">Instagram</a></li> 							</ul> 							<ul class="copyright"> 								<li>&copy; Solid Inc. All rights reserved.</li><li>Scripts by: <a href="mailto:hassanraza.king1@gmail.com"></a>King</li> 							</ul> 						</div> 					</section> 			</div>					</section> 			</div> 		<!-- Scripts --> 			<script src="assets/js/skel.min.js"></script> 			<script src="assets/js/jquery.min.js"></script> 			<script src="assets/js/jquery.scrollex.min.js"></script> 			<script src="assets/js/util.js"></script> 			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]--> 			<script src="assets/js/main.js"></script> 	</body> 

</body>
</html>
