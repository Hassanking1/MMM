<?php
$con = @mysqli_connect('localhost', 'root', '1234@$ZXCV', 'register'); if (!$con) { echo "Error: " . mysqli_connect_error(); 	exit(); }
?>