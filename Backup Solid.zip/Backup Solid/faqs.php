<!DOCTYPE HTML>
<html>
	<head><?php 
include "logo.php";
?>
    <meta charset="utf-8">
    <meta name="keywords" content="contributions, member to member, peer to peer, funding, crowd, crowd funding">
    <meta name="description" content="Member to Member Contributions Platform">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> FAQs | Solid</title>
    <script src="/cdn-cgi/apps/head/VAJ5gVQeZIkHrO9JprS30wkz4Sk.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header">
						<h1><a href="home.php">Solid Matrix</a></h1>
						<nav> 							<a href="#menu">Menu</a> 						</nav> 					</header> 				<!-- Menu --> 				<nav id="menu"> 						<div class="inner"> 							<h2>Menu</h2> 							<ul class="links"> 								<li><a href="home.php">Home</a></li> 								<li><a href="howitworks.php">How it works</a></li> 								<li><a href="faqs.php">FAQs</a></li> 								<li><a href="login.php">Log In</a></li> 								<li><a href="register.php">Sign Up</a></li> 			 <li><a href="aboutus.php">About us</a></li>				<li><a href="terms.php">Terms & Conditions</a>
</li></ul> 							<a href="#" class="close">Close</a> 						</div> 					</nav>

				<!-- Wrapper -->
					<section id="wrapper">
						<header>
							<div class="inner">
								<h2>FAQS</h2>
								<p>Frequently asked questions.</p>
							</div>
						</header>

						<!-- Content -->
							<div class="wrapper">
								<div class="inner">

									<h3 class="major">Please take a moment to read them.</h3>
							<section class="second-sectio-back min">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="front-page">
                    <p><span style="text-decoration: underline;"><span style="font-family: helvetica; font-size: 18pt;"><strong>FAQs</strong></span></span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q1. What is SOLID?</span></p>
<p><span style="color: #339966; font-family: helvetica; font-size: 14pt;">A. SOLID is a Automatic Service where members make a contribution to have access to different kinds of digital media and services on the Solid Platform.</span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q2. How does SOLID work?</span></p>
<p><span style="color: #339966; font-family: helvetica; font-size: 14pt;">A. When you join SOLID you join a community of like-minded members who are interested in subscribing to valuable content and services. Our subscription membership is private.</span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q3. How do I join SOLID?</span></p>
<p><span style="color: #339966; font-family: helvetica; font-size: 14pt;">A. Get in touch with the person who invited you to provide you the link. Use that link to sign up.</span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q4. Is SOLID available worldwide?</span></p>
<p><span style="color: #339966; font-family: helvetica; font-size: 14pt;">A. Yes, SOLID is available to anyone with an internet connection, a Bitcoin wallet and the willingness to become a member.</span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q5. What pay processors are used?</span></p>
<p><span style="color: #339966; font-family: helvetica; font-size: 14pt;">A. We only use Bitcoin to make it easy for members to make contributions to other members.</span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q6. Can I have more than one account?</span></p>
<p><span style="color: #339966; font-family: helvetica; font-size: 14pt;">A. Yes you can but it is strongly recommended that you do not stack them. For example, you create another personal account under your first account. This is considered stacking. This is an unethical practice.</span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q7. Are there any refunds?</span></p>
<p><span style="color: #339966; font-family: helvetica; font-size: 14pt;">A. All contributions happen automatic and it is up to you.And there are no refunds once you joined</span></p>
<p><span style="color: #0000ff;"><span style="font-family: helvetica;"><span style="font-size: 18.6667px;">Q8. </span></span><span style="font-family: helvetica; font-size: 14pt;">I don't have a bitcoin wallet where do I go to open a bitcoin wallet.</span></span></p>
<p><span style="font-family: helvetica; font-size: 14pt; color: #339966;">A. The only places we highly recommend you go get a Bitcoin wallet is at <a href="https://blockchain.info/wallet/">Blockchain</a> or <a href="https://www.coinbase.com/join/registerhere" target="_blank">Coinbase</a> and the best Debit Card to have in my opinion is the <a href="https://www.e-coin.io/?ref=34b93b38a2c049cc86c55a48ea480a8e">Wirex Debit Card</a>.  For Namibians and other parts of the world where the Wirex card is not accepted use the <a href="https://spectrocoin.com/en/signup.html?referralId=538799117">Spectrocoin Card</a>.</span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q9. Do we only upgrade to the next level after receiving 3 paymentd?</span></span></span></p>
<p><span style="font-family: helvetica; font-size: 14pt; color: #339966;">A. You should not have to worry about upgrade to the next level, this is an automatic matrix.</span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q10. When will two people be assigned to me? I was under the impression that as each person joins they are assigned under each person and so forth under my level?</span></p>
<p><span style="color: #339966; font-family: helvetica; font-size: 14pt;">A. YOU will need to to wait for members to join or to get fast share our platform , people to join you and you can then help  people to grow your team.It will help every member to get spillovers.</span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q11. Isn't this like a pyramid scheme?</span></p>
<p><span style="color: #339966; font-family: helvetica; font-size: 14pt;">A. Well a pyramid scheme means that only the top members of the hierarchy get paid whereas Solid allows every member to earn the same amount by doing the same amount of work. You can receive more contributions than the person who signed you up, that fact makes Solid a fair system.</span></p>
<p><span style="color: #0000ff; font-family: helvetica; font-size: 14pt;">Q12. Can I use the same IP address to help my team to open accounts for multiple people?</span></p>
<p><span style="color: #339966; font-family: helvetica; font-size: 14pt;">A. Yes you may as long as you don't stack accounts.</span></p>
<p style="text-align: center;"><strong><span style="font-family: helvetica; font-size: 14pt; color: #ff0000; background-color: #ffff00;">The platform is made available World-Wide, free of charge.</span></strong></p>
<p style="text-align: center;"><strong><span style="font-family: helvetica; font-size: 14pt; color: #ff0000; background-color: #ffff00;">There are No Admin fees.</span></strong></p>
<p style="text-align: center;"><strong><span style="font-family: helvetica; font-size: 14pt; color: #ff0000; background-color: #ffff00;">SOLID is a automatic payment Contribution Platform.</span></strong></p>
<p style="text-align: center;"><strong><span style="font-family: helvetica; font-size: 14pt; color: #ff0000; background-color: #ffff00;">The system is designed in such a way that it can be used by members to make and receive payments.</span></strong></p>
<p style="text-align: center;"><strong><span style="font-family: helvetica; font-size: 14pt; color: #ff0000; background-color: #ffff00;">The entry fees are NOT collected by the Administrator, they are automated by the system.</span></strong></p>

				<!-- Footer -->
					<section id="footer"> 						<div class="inner"> 									<ul class="contact"> 																<li class="fa-phone">(067) 546-8296</li> 								<li class="fa-envelope"><a href="mailto:Hassanraza.king1@gmail.com">Contact us</a></li> 								<li class="fa-facebook"><a href="fb.com/hassanrazaking.king">Facebook</a></li> 								<li class="fa-instagram"><a href="instagram.com/#">Instagram</a></li> 							</ul> 							<ul class="copyright"> 								<li>&copy; Solid Inc. All rights reserved.</li><li>Scripts by: <a href="mailto:hassanraza.king1@gmail.com"></a>King</li> 							</ul> 						</div> 					</section> 			</div>

		<!-- Scripts -->
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>