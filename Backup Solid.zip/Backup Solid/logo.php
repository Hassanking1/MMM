<html>
<head>


		<!-- Favicon -->
		<link rel="icon" type="image/png" sizes="56x56" href="images/icon.png">
</head>
<body>

</body>
</html>